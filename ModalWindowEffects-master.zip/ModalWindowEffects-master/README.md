
Modal Window Effects
=========
A set of experimental modal window appearance effects with CSS transitions and animations. 

[article on Codrops](http://tympanus.net/codrops/?p=15313)

[demo](http://tympanus.net/Development/ModalWindowEffects/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)